import datetime
import sys
import io
import clr
import os
import glob
import os.path
from os import path
import random
import time
import re
import json
import ast

clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")

ScriptName = "!players"
Website = "https://www.twitch.tv/th_mrow"
Description = "Gives you the amount of players in your spellbreak game."
Creator = "th_mrow"
Version = "1.0"

m_CommandPermission = "moderator"
m_LogFileFolderPath = r'%LOCALAPPDATA%\g3\Saved\Logs'
m_FileType = '\*log'
m_LookFor = "blob data for"

#return the path of the lastest log file create
def LastestFile():
    files = glob.glob(path.expandvars(m_LogFileFolderPath) + m_FileType)
    max_file = max(files, key=os.path.getctime)
    return max_file

def WriteLastestFile(file):
    latestFile = os.path.join(os.path.dirname(__file__), "LatestLogPath.txt")
    latestFileWrite = open(latestFile, "w")
    latestFileWrite.write('%s' % str(file))
    latestFileWrite.close()
    return

def GetLastestFile():
    latestFile = os.path.join(os.path.dirname(__file__), "LatestLogPath.txt")
    latestFileRead = open(latestFile, "r")
    latestFile_str = latestFileRead.readline()
    latestFileRead.close()
    return latestFile_str

def ReadOldPlayers():
    oldPlayers = os.path.join(os.path.dirname(__file__), "PreviousTotalPlayers.txt")
    oldPlayersRead = open(oldPlayers, "r")
    oldPlayers_str = oldPlayersRead.readline()
    oldPlayersRead.close()
    return int(float(oldPlayers_str))

def ResetOldPlayers():
    oldPlayers = os.path.join(os.path.dirname(__file__), "PreviousTotalPlayers.txt")
    oldPlayersWrite = open(oldPlayers, "w")
    oldPlayersWrite.write('%s' % str(0))
    oldPlayersWrite.close()
    return

def ChangeOldPlayers(newPlayers):
    oldPlayers = os.path.join(os.path.dirname(__file__), "PreviousTotalPlayers.txt")
    oldPlayersWrite = open(oldPlayers, "w")
    oldPlayersWrite.write('%s' % str(newPlayers))
    oldPlayersWrite.close()
    return

def AddOldPlayers(newPlayers):
    formerOldPlayers = ReadOldPlayers()
    totalOldPlayers = formerOldPlayers + newPlayers
    oldPlayers = os.path.join(os.path.dirname(__file__), "PreviousTotalPlayers.txt")
    oldPlayersWrite = open(oldPlayers, "w")
    oldPlayersWrite.write('%s' % str(totalOldPlayers))
    oldPlayersWrite.close()
    return

def ReadPlayers():
    players = os.path.join(os.path.dirname(__file__), "TotalPlayers.txt")
    playersRead = open(players, "r")
    players_str = playersRead.readline()
    playersRead.close()
    return int(float(players_str))

def ResetPlayers():
    players = os.path.join(os.path.dirname(__file__), "TotalPlayers.txt")
    playersWrite = open(players, "w")
    resetVal = ReadOldPlayers()
    playersWrite.write('%s' % str(resetVal))
    playersWrite.close()
    return

def ChangePlayers(newPlayers):
    players = os.path.join(os.path.dirname(__file__), "TotalPlayers.txt")
    playersWrite = open(players, "w")
    playersWrite.write('%s' % str(newPlayers))
    playersWrite.close()
    return

def ReadSavePlayers():
    players = os.path.join(os.path.dirname(__file__), "Players.txt")
    playersRead = open(players, "r")
    players_str = playersRead.readline()
    playersRead.close()
    return int(float(players_str))

def ResetSavePlayers():
    players = os.path.join(os.path.dirname(__file__), "Players.txt")
    playersWrite = open(players, "w")
    playersWrite.write('%s' % str(0))
    playersWrite.close()
    return

def ChangeSavePlayers(newPlayers):
    players = os.path.join(os.path.dirname(__file__), "Players.txt")
    playersWrite = open(players, "w")
    playersWrite.write('%s' % str(newPlayers))
    playersWrite.close()
    return

def GetLogPLayers(logPath):
    playersRead = open(logPath, "r")
    players_str = playersRead.read()
    amount = players_str.count(m_LookFor)
    playersRead.close()
    return amount

def StartPlayers():
    totalOldPlayers = ReadOldPlayers()
    totalPlayers = ReadPlayers()
    players = totalPlayers - totalOldPlayers
    if players != 0:
        ChangeSavePlayers(players)
    return players

def WritePlayerData(data):
    players = os.path.join(os.path.dirname(__file__), "PlayersData.txt")
    playersWrite = open(players, "w")
    playersWrite.write('%s' % str(data))
    playersWrite.close()
    return

def ResetPlayerData():
    players = os.path.join(os.path.dirname(__file__), "PlayersData.txt")
    playersWrite = open(players, "w")
    playersWrite.write('%s' % str(""))
    playersWrite.close()
    return

def ReadPlayerData():
    players = os.path.join(os.path.dirname(__file__), "PlayersData.txt")
    playersRead = open(players, "r")
    players_str = playersRead.read()
    playersRead.close()
    players_list = ast.literal_eval(players_str)
    return players_list

def WritePlayerName(data):
    players = os.path.join(os.path.dirname(__file__), "PlayersName.txt")
    playersWrite = open(players, "a")
    playersWrite.write('%s' % str(data) + "\n")
    playersWrite.close()
    return

def ResetPlayerName():
    players = os.path.join(os.path.dirname(__file__), "PlayersName.txt")
    playersWrite = open(players, "w")
    playersWrite.write('%s' % str(""))
    playersWrite.close()
    return

def ReadPlayerName():
    players = os.path.join(os.path.dirname(__file__), "PlayersName.txt")
    playersRead = open(players, "r")
    players_list = playersRead.readlines()
    playersRead.close()
    return players_list

def ConvertToJson(line):
    lineJson = json.loads(line)
    return lineJson

def GetJsonLine(line):
    excla = line.count("!")
    separate = line.split("!", excla)
    answer = separate[0]
    separate2 = answer.split(":", 5)
    answer2 = separate2[5]
    return answer2

def FoundPlayersInfo(logPath):
    list = []
    logRead = open(logPath, "r")
    log_list = logRead.readlines()
    logRead.close()
    for line in log_list:
        if line.count(m_LookFor) !=0 :
            json = GetJsonLine(line)
            list.append(json)
    WritePlayerData(list)
    return

def WrotePlayersName():
    ResetPlayerName()
    list = ReadPlayerData()
    nbPlayers = ReadSavePlayers()
    if nbPlayers == len(list):
        nbPlayers = 0
    for i in range(len(list)-nbPlayers, len(list)):
        lineJson = ConvertToJson(list[i])
        WritePlayerName(lineJson['DisplayName'])
    return

def Init():
    return

def Execute(data):
    if data.IsChatMessage():
        if data.GetParam(0) == "!players":

            if (data.GetParamCount() == 1):
                players = ReadSavePlayers()
                answer = "There is " + str(players) + " players, including the streamer team."
                Parent.SendTwitchMessage(answer)
                return

            #Check if there is a new log and reset old players if yes
            if data.GetParam(1) == "init" and Parent.HasPermission(data.User, m_CommandPermission,"Get the most recent log file and reset if new one"):
                lastest = LastestFile()
                lastestMemory = GetLastestFile()
                if (lastest != lastestMemory):
                    WriteLastestFile(lastest)
                    ResetOldPlayers()
                    Parent.SendTwitchMessage("Old players reset")
                ResetSavePlayers()
                ResetPlayers()
                Parent.SendTwitchMessage("Init done")
                return

            if data.GetParam(1) == "update" and Parent.HasPermission(data.User, m_CommandPermission,"Get the amount of player in your lobby"):
                path = LastestFile()
                totPlayers = GetLogPLayers(path)
                ChangePlayers(totPlayers)
                players = StartPlayers() + ReadSavePlayers()
                answer = "There is " + str(players) + " players, including your team."
                ChangeSavePlayers(players)
                ChangeOldPlayers(totPlayers)
                Parent.SendTwitchMessage(answer)
                return

            if data.GetParam(1) == "newGame" and Parent.HasPermission(data.User, m_CommandPermission,"Reset players and old players"):
                path = LastestFile()
                totPlayers = GetLogPLayers(path)
                ChangePlayers(totPlayers)
                players = StartPlayers()
                if players != 0:
                    answer = "There is " + str(players) + " players, including your team."
                    ChangeOldPlayers(totPlayers)
                    Parent.SendTwitchMessage(answer)
                    ResetPlayerData()

                else:
                    Parent.SendTwitchMessage("You are still in the same match")
                return

            if data.GetParam(1) == "reset" and Parent.HasPermission(data.User, m_CommandPermission,"Reset players and old players"):
                ResetPlayers()
                ResetOldPlayers()
                ResetSavePlayers()
                ResetPlayerData()
                ResetPlayerName()
                Parent.SendTwitchMessage("reset done")
                return

            if data.GetParam(1) == "help":
                Parent.SendTwitchMessage("!players : to see how many players there is")
                Parent.SendTwitchMessage("!players name : to see the names of all the players in your lobby")
                Parent.SendTwitchMessage("!players newGame(mod+): to calculate the new amount of player there is  (to do at the end of the pre-lobby)")
                Parent.SendTwitchMessage("!players update(mod+): to update the new amount of player there is in the lobby")
                Parent.SendTwitchMessage("!players init(mod+): to init the command after launching the game")
                Parent.SendTwitchMessage("!players reset(mod+): to reset ")
                return

            if data.GetParam(1) == "name":
                path = LastestFile()
                FoundPlayersInfo(path)
                WrotePlayersName()
                list = ReadPlayerName()
                for name in list :
                    Parent.SendTwitchMessage(str(name))
                Parent.SendTwitchMessage("End of the player list")
                return
            return
        return
    return


def Tick():
    return