import datetime
import sys
import io
import clr
import os
import random
import time

clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")

ScriptName="!queue"
Website=""
Description="Save the time spent in queue"
Creator="th_mrow"
Version="1.0.0"

m_CommandPermission="moderator"

#Start the timer
def StartTimer():
    startTimer = time.time()
    Parent.SendTwitchMessage("Random accept answer.")
    timer = os.path.join(os.path.dirname(__file__), "Timer.txt")
    timerWrite = open(timer, "w")
    timerWrite.write('%s' % str(startTimer))
    timerWrite.close()
    return

#End the timer and return the time passed in second
def EndTimer():
    endTimer = time.time()
    timer = os.path.join(os.path.dirname(__file__), "Timer.txt")
    timerRead = open(timer, "r")
    timer_str = timerRead.readline()
    timerRead.close()
    startTimer = float(timer_str)
    if (startTimer != 0):
        totalTime = endTimer - startTimer
        return totalTime
    else :
        return 0 #If you didn't start the timer

#Return the timer time as an int
def ReadTimer():
    timer = os.path.join(os.path.dirname(__file__), "Timer.txt")
    timerRead = open(timer, "r")
    timer_str = timerRead.readline()
    timerRead.close()
    return  int(float(timer_str))

#Set the timer at 0 (not the queue time)
def InitTimer():
    timer = os.path.join(os.path.dirname(__file__), "Timer.txt")
    timerWrite = open(timer, "w")
    timerWrite.write('%s' % str(0))
    timerWrite.close()
    return

#Reset the timer (not the queue time)
def ResetTimer():
    startTimer = time.time()
    timer = os.path.join(os.path.dirname(__file__), "Timer.txt")
    timerWrite = open(timer, "w")
    timerWrite.write('%s' % str(startTimer))
    timerWrite.close()
    return

#Return the queue time as an int
def ReadQueue():
    queue = os.path.join(os.path.dirname(__file__), "Queue.txt")
    queueRead = open(queue, "r")
    queue_str = queueRead.readline()
    queueRead.close()
    return  int(float(queue_str))

#Set queue time to 0
def ResetTimerQueue():
    timer = os.path.join(os.path.dirname(__file__), "Queue.txt")
    timerWrite = open(timer, "w")
    timerWrite.write('%s' % str(0))
    timerWrite.close()
    return

#Add a time to the queue
#Timer in second
def AddTimeToQueue(time):
    oldQueueTime = ReadQueue()
    time += oldQueueTime
    timer = os.path.join(os.path.dirname(__file__), "Queue.txt")
    timerWrite = open(timer, "w")
    timerWrite.write('%s' % str(int(time)))
    timerWrite.close()
    return

def Init():
    return

def Execute(data):
    if data.IsChatMessage():
        #return the local time
        if data.GetParam(0) == "!time":
            Parent.SendTwitchMessage(time.strftime("%a, %d %b %Y %H:%M:%S", time.localtime()))
            return
        # Print the queue time
        if data.GetParam(0) == "!queue":
            #print the queue time
            if (data.GetParamCount() == 1):
                queue = ReadQueue()
                Parent.SendTwitchMessage(time.strftime("%H:%M:%S", time.gmtime(queue)))
                return
            #reset the queue time
            if data.GetParam(1) == "reset" and Parent.HasPermission(data.User, m_CommandPermission, "Reset the timer."):
                ResetTimerQueue()
                Parent.SendTwitchMessage("Reset of the queue time done")
            return

        #Contain all the function about the timer
        if data.GetParam(0) == "!timer":
            #Print the timer without reseting it
            if (data.GetParamCount() == 1):
                endTimer = time.time()
                timer = ReadTimer()
                if (timer != 0):
                    totalTime = endTimer - timer
                else:
                    totalTime = 0   # If you didn't start the timer
                Parent.SendTwitchMessage(time.strftime("%H:%M:%S", time.gmtime(totalTime)))
                return
            #Start the timer
            if data.GetParam(1) == "start" and Parent.HasPermission(data.User,m_CommandPermission, "Starting the timer."):
                StartTimer()
                return

            #Stop the timer and add the time in the queue time
            if data.GetParam(1) == "stop" and Parent.HasPermission(data.User,m_CommandPermission, "Ending the timer."):
                timer = EndTimer()
                AddTimeToQueue(timer)
                InitTimer()
                Parent.SendTwitchMessage(time.strftime("%H:%M:%S", time.gmtime(timer)))
                return

            #Reset the timer time
            if data.GetParam(1) == "reset" and Parent.HasPermission(data.User,m_CommandPermission, "Reset the timer."):
                ResetTimer()
                Parent.SendTwitchMessage("Reset of the timer done")
            return
        return

def Tick():
    return
